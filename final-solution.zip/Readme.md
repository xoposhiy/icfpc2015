# Hack the loop team
## ICFPC 2015

Team members are listed here:
https://git.skbkontur.ru/pe/icfpc-2015/project_members

Prebuilt solution play_icfp2015.exe is located in bin directory - you can run it directly.

How to build:

0. Suppose we are running inside Windows OS

1. Make sure .NET 4.6 and MS Build Tools are installed (see below)

	1.1. You can get Microsoft .NET Framework 4.6 here: https://go.microsoft.com/fwlink/?LinkId=528222

	1.2. You can get Microsoft Build Tools 2015 here: https://go.microsoft.com/fwlink/?LinkId=615458

	1.3. Or instead of installing different packages you can just install Visual Studio Community Edition

2. Run build.cmd

3. Executable play_icfp2015.exe will be built into bin directory