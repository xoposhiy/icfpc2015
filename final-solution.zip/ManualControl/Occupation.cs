﻿namespace ManualControl
{
    public enum Occupation
    {
        Empty,
        Occupied,
        Unit,
    }
}