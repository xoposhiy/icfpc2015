using System.Net;

namespace Lib
{
	public class SubmitionJson
	{
		public int problemId { get; set; }

		public int seed { get; set; }

		public string tag { get; set; }

		public string solution { get; set; }
	}
}