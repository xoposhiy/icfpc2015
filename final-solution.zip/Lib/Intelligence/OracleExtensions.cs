﻿using System;
using System.Collections;
using System.Collections.Generic;
using Lib.Models;
using System.Linq;
using Lib.Finder;

namespace Lib.Intelligence
{

    public static class OracleExtensions
    {
        }
    
}