using Lib.Models;

namespace Lib.Intelligence
{
    public class Lookaheader
    {

        public double Estimate(Map map, PositionedUnit unit)
        {
            
            return 42;
        }
        
    }
}