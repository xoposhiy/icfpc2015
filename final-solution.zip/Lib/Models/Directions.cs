﻿namespace Lib.Models
{
	public enum Directions
	{
		SE,
		SW,
		E,
		W,
		CW,
		CCW
	}
}